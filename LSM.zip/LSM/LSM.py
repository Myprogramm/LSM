import pandas as pd
from time import time
from math import exp, sqrt, log
from random import gauss, seed
import matplotlib.pyplot as plt
import numpy as np
import LSMfunc as lsm
seed(100)  # seed （）方法改变随机数生成器的种子
start = time()
file_path = '0323CBD.csv'
df = pd.read_csv(file_path)
M=100
I=2000
Price = []
i=0
for index,row in df.iterrows():
    #输入数据
    C_name = row[1] #name
    C_b = row[4]  # 债底价值
    # print('V_b=%.6f'%V_b)
    S_0 = row[6]  # 股票的初始价格：
    K_0 = row[5]# 行权价格
    T = row[7]# 期权的到期年限（距离到期日的时间间隔）
    P = row[2]
    # ime enterval，时间间隔
    dt = T / M
    sigma = row[3]/100  # 波动率（收益标准差）
    r=0.027 #无风险利率，手动更新！
    #预测函数
    price_temp = lsm.LSMfunction4(S_0,K_0,sigma,r,T,I,M,C_b,P)
    i=i+1
    if price_temp != -1:
        print("(%f)has been done"%i+C_name+"price is %.2f"%price_temp)

    Price.append(price_temp)
df.insert(df.shape[1],' Price ',Price)

#输出到excel
df.to_excel('0323.xlsx')

# 可视化
# plt.figure(figsize=(10, 6))
# plt.grid(True)
# plt.xlabel('num')
# plt.ylabel('price')
# df.plot(y='Price')
# plt.show()
