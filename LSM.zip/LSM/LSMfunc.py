import numpy as np
from math import exp, sqrt, log
from random import gauss, seed
import matplotlib.pyplot as plt

#纯美式期权
def LSMAmericanOption(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt=T/M
    df1=exp(-r*dt)
    S=np.zeros((M+1,I))
    S[0]=S_0
    z=np.zeros((M+1,I))
    for i in range(I):
        for j in range(M+1):
            z[j][i]=gauss(0.0,1.0)

    for t in range(1,M+1):
        S[t]=S[t-1]*np.exp((r-0.5*sigma**2)*dt+sigma*sqrt(dt)*z[t])

    h=np.maximum(S-K_0,0)

    V=np.copy(h)
    for t in range(M - 1, 0, -1):
        reg = np.polyfit(S[t], V[t - 1] * dt, 2)
        C = np.polyval(reg, S[t])
        V[t] = np.where(C > h[t], V[t+1]*df1 , h[t])
    C_0=df1*np.mean(V[1])
    P_cb = V_b + C_0 * 100 / K_0
    return C_0
def LSMfunction(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt = T / M
    S = np.zeros((I, M + 1))
    tiexian = []
    for i in range(I):
        path = []

        # 时间间隔上的模拟路径
        for t in range(M + 1):
            if t == 0:
                path.append(S_0)
            else:
                z = gauss(0.0, 1.0)
                S_t = path[t - 1] * exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrt(dt) * z)
                path.append(S_t)
        S[i] = path

    V = S - K_0
    # 最小二乘法回归
    for i in range(M - 1):
        Ytemp = S[:, M - i] - K_0
        Xtemp = S[:, M - 1 - i]
        # 筛选参与回归的路径,规则为这一期股价>行权价的可以参与回归
        idx = np.argwhere(np.all(Xtemp) <= K_0)
        VV = np.delete(Ytemp, idx)
        X = np.delete(Xtemp, idx)
        # 解释变量为这一期的股价
        # 被解释变量为下一期价值贴现
        Y = VV * exp(-r * dt)
        reg = np.polyfit(X, Y, 2)
        # val为这一期股价对应的持有期望收益
        val = np.polyval(reg, S[:, M - 1 - i])
        # 对比I条路径下持有期望收益和转股哪个划算，将期权改期期望价值改写为大值
        for j in range(0, I):
            if val[j] > (S[j, M - 1 - i] - K_0):
                V[j, M - 1 - i] = max(val[j], 0)
            else:
                V[j, M - 1 - i] = max(0, S[j, M - 1 - i] - K_0)
        # 到这里第M-1-i步的期望价值已经全部替换
    # 计算期权现值
    C_0 = exp(-r * dt) * (sum(V[:, 1])) / I  # tiexian
    P_cb = V_b + C_0 * 100 / K_0
    return P_cb
    # print(C_name+'CB price %.2f' % P_cb+" Price: %.2f" %PCb)
#带赎回条款的
def LSMfunction1(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt = T / M
    S = np.zeros((I, M + 1))
    tiexian = []
    for i in range(I):
        path = []

        # 时间间隔上的模拟路径
        for t in range(M + 1):
            if t == 0:
                path.append(S_0)
            else:
                z = gauss(0.0, 1.0)
                S_t = path[t - 1] * exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrt(dt) * z)
                path.append(S_t)
        S[i] = path
    # 可视化
    # plt.figure(figsize=(10, 6))
    # plt.grid(True)
    # plt.xlabel('Time step')
    # plt.ylabel('index level')
    # for i in range(1000):
    #     plt.plot(S[i])
    # plt.show()
    # xxx=1
    # 选出强赎路径
    # 触发条款筛选
    tiexian = 0
    shnum = 0
    for i in range(I):
        for t in range(M):
            if S[i][t] * 100 / K_0 > 130:
                # 多少路径完成赎回
                shnum = shnum + 1
                # 赎回的直接贴现到0期
                tiexian = tiexian + (S[i][t] - K_0) * exp(-r * dt * t)
                S[i] = 0
                break
                # 如果触发赎回
    # 数据清洗,删除赎回的路径,axis = 0 lie
    if shnum == I:
        C_0 = tiexian * exp(-r * dt) / shnum
        P_cb = V_b + C_0 * 100 / K_0
        return P_cb
    idx = np.argwhere(np.all(S[:, ...] == 0, axis=1))
    # axis = 0,hang
    SS = np.delete(S, idx, axis=0)
    # V: (I-shnum)*(M+1)
    V = SS - K_0
    # 最小二乘法回归
    for i in range(M - 1):
        Ytemp = SS[:, M - i] - K_0
        Xtemp = SS[:, M - 1 - i]
        # 筛选参与回归的路径,规则为这一期股价>行权价的可以参与回归
        idx = np.argwhere(np.all(Xtemp) <= K_0)
        VV = np.delete(Ytemp, idx)
        X = np.delete(Xtemp, idx)
        # 解释变量为这一期的股价
        # 被解释变量为下一期价值贴现
        Y = VV * exp(-r * dt)
        reg = np.polyfit(X, Y, 2)
        # val为这一期股价对应的持有期望收益
        val = np.polyval(reg, SS[:, M - 1 - i])
        # 对比I条路径下持有期望收益和转股哪个划算，将期权改期期望价值改写为大值
        for j in range(0, I - shnum):
            if val[j] > (SS[j, M - 1 - i] - K_0):
                V[j, M - 1 - i] = max(val[j], 0)
            else:
                V[j, M - 1 - i] = max(0, SS[j, M - 1 - i] - K_0)
        # 到这里第M-1-i步的期望价值已经全部替换
    # 计算期权现值
    C_0 = exp(-r * dt) * (sum(V[:, 1]) + tiexian) / I  # tiexian
    P_cb = V_b + C_0 * 100 / K_0
    return P_cb
    #print(C_name+'CB price %.2f' % P_cb+" Price: %.2f" %PCb)
#带赎回回售下修条款的
def LSMfunction2(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt = T / M
    S = np.zeros((I, M + 1))
    tiexian = []
    for i in range(I):
        path = []

        # 时间间隔上的模拟路径
        for t in range(M + 1):
            if t == 0:
                path.append(S_0)
            else:
                z = gauss(0.0, 1.0)
                S_t = path[t - 1] * exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrt(dt) * z)
                path.append(S_t)
        S[i] = path
    # 可视化
    # plt.figure(figsize=(10, 6))
    # plt.grid(True)
    # plt.xlabel('Time step')
    # plt.ylabel('index level')
    # for i in range(1000):
    #     plt.plot(S[i])
    # plt.show()
    # xxx=1
    # 选出强赎路径
    # 触发条款筛选
    tiexian = 0
    shnum = 0
    K = np.zeros((I, M + 1))
    K[:] = K_0
    redays=0
    for i in range(I):
        # 假设达到赎回条件并且剩余期限小于5年的转债选择赎回
        if (S[i][t] * 100 / K[i][t]) > 130 and (T - t * dt) <= 5:
            # 多少路径完成赎回
            shnum = shnum + 1
            # 赎回的直接贴现到0期
            tiexian = tiexian + (S[i][t] - K[i][t]) * exp(-r * dt * t)
            S[i] = 0
        # 如果触发下修条件，为避免回售选择下修
        if S[i][t] < 0.7 * K[i][t] and (T - t * dt) <= 2:
            temp=0
            for tt in range(t,t-10,-1):
                temp=temp+S[i][tt]
            K[i][t:] = temp/10
    # 数据清洗,删除赎回的路径,axis = 0 lie
    if I-shnum<0.01*I:
        C_0=tiexian*exp(-r*dt)/shnum
        P_cb = V_b + C_0 * 100 / K_0
        return P_cb
    else:
        idx = np.argwhere(np.all(S[:, ...] == 0, axis=1))
        # axis = 0,hang
        SS = np.delete(S, idx, axis=0)
        K = np.delete(K, idx, axis=0)
        # V: (I-shnum)*(M+1)
        V = SS - K
        # 最小二乘法回归
        for i in range(M - 1):
            Ytemp = SS[:, M - i] - K[:, M - i]
            Xtemp = SS[:, M - 1 - i]
            # 筛选参与回归的路径,规则为这一期股价>行权价的可以参与回归
            idx = []
            for qq in range(I - shnum):
                if Xtemp[qq] <= K[qq, M - 1 - i]:
                    idx.append(qq)
            # idx=np.argwhere(np.all(Xtemp)<=K[:,M-1-i])
            VV = np.delete(Ytemp, idx)
            X = np.delete(Xtemp, idx)
            # 解释变量为这一期的股价
            # 被解释变量为下一期价值贴现
            Y = VV * exp(-r * dt)
            if len(X)==0:
                V[:,1]=V[:,M-i]*exp(-dt*r*(M-i-1))
            else:
                reg = np.polyfit(X, Y, 2)
                 # val为这一期股价对应的持有期望收益
                val = np.polyval(reg, SS[:, M - 1 - i])
                # 对比I条路径下持有期望收益和转股哪个划算，将期权改期期望价值改写为大值
                for j in range(0, I - shnum):
                    if val[j] > (SS[j, M - 1 - i] - K[j, M - 1 - i]):
                        V[j, M - 1 - i] = max(val[j], 0)
                    else:
                        V[j, M - 1 - i] = max(0, SS[j, M - 1 - i] - K[j][M - 1 - i])
                    # 到这里第M-1-i步的期望价值已经全部替换
        # 计算期权现值
        C_0 = exp(-r * dt) * (sum(V[:, 1]) + tiexian) / I  # tiexian
        P_cb = V_b + C_0 * 100 / K_0
        return P_cb
#转股价值贴现算法
def LSMfunction3(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt = T / M
    S = np.zeros((I, M + 1))
    tiexian = []
    for i in range(I):
        path = []

        # 时间间隔上的模拟路径
        for t in range(M + 1):
            if t == 0:
                path.append(S_0)
            else:
                z = gauss(0.0, 1.0)
                S_t = path[t - 1] * exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrt(dt) * z)
                path.append(S_t)
        S[i] = path

    # 选出强赎路径
    # 触发条款筛选
    tiexian = 0
    shnum = 0
    K = np.zeros((I, M + 1))
    K[:] = K_0
    for i in range(I):
        # 假设达到赎回条件并且剩余期限小于5年的转债选择赎回
        if (S[i][t] * 100 / K[i][t]) > 130 and (T - t * dt) <= 5:
            # 多少路径完成赎回
            shnum = shnum + 1
            # 赎回的直接贴现到0期
            tiexian = tiexian + (S[i][t]*100/K[i][t]) * exp(-r * dt * t)
            S[i] = 0
        # 如果触发下修条件，为避免回售选择下修
        if S[i][t] < 0.7 * K[i][t] and (T - t * dt) <= 2:
            temp=0
            for tt in range(t,t-10,-1):
                temp=temp+S[i][tt]
            #K[i][t:] = max(temp/10,0.95*K[i][t])
    # 数据清洗,删除赎回的路径,axis = 0 lie
    if I-shnum==I:
        C_0=tiexian*exp(-r*dt)/shnum
        P_cb = C_0
        return P_cb
    else:
        idx = np.argwhere(np.all(S[:, ...] == 0, axis=1))
        # axis = 0,hang
        SS = np.delete(S, idx, axis=0)
        K = np.delete(K, idx, axis=0)
        # V: (I-shnum)*(M+1)
        V = SS - K
        # 最小二乘法回归
        for i in range(M - 1):
            Ytemp = SS[:, M - i]*100/K[:, M - i]
            Xtemp = SS[:, M - 1 - i]
            # 筛选参与回归的路径,规则为这一期股价>行权价的可以参与回归
            idx = []
            for qq in range(I - shnum):
                if Xtemp[qq] <= K[qq, M - 1 - i]:
                    idx.append(qq)
            # idx=np.argwhere(np.all(Xtemp)<=K[:,M-1-i])
            VV = np.delete(Ytemp, idx)
            X = np.delete(Xtemp, idx)
            # 解释变量为这一期的股价
            # 被解释变量为下一期价值贴现
            Y = VV * exp(-r * dt)
            if len(X)==0:
                V[:,1]=V[:,M-i]*exp(-dt*r*(M-i-1))
            else:
                reg = np.polyfit(X, Y, 2)
                 # val为这一期股价对应的持有期望收益
                val = np.polyval(reg, SS[:, M - 1 - i])
                # 对比I条路径下持有期望收益和转股哪个划算，将期权改期期望价值改写为大值
                for j in range(0, I - shnum):
                    if val[j] > (SS[j, M - 1 - i]*100/  K[j, M - 1 - i]):
                        V[j, M - 1 - i] = max(val[j], 0)
                    else:
                        V[j, M - 1 - i] = max(0, SS[j, M - 1 - i]*100/K[j][M - 1 - i])
                    # 到这里第M-1-i步的期望价值已经全部替换
        for ii in range(0, I - shnum):
            if V[ii, 1] < (V_b * exp(r * dt)):
                V[ii, 1] = V_b * exp(r * dt)
        # 计算期权现值
        P_cb = exp(-r * dt) * (sum(V[:, 1]) + tiexian) / I  # tiexian
        return P_cb
def LSMfunction4(S_0,K_0,sigma,r,T,I,M,V_b,PCb):
    dt = T / M
    S = np.zeros((I, M + 1))
    tiexian = []
    for i in range(I):
        path = []

        # 时间间隔上的模拟路径
        for t in range(M + 1):
            if t == 0:
                path.append(S_0)
            else:
                z = gauss(0.0, 1.0)
                S_t = path[t - 1] * exp((r - 0.5 * sigma ** 2) * dt + sigma * sqrt(dt) * z)
                path.append(S_t)
        S[i] = path
    # 可视化
    # plt.figure(figsize=(10, 6))
    # plt.grid(True)
    # plt.xlabel('Time step')
    # plt.ylabel('index level')
    # for i in range(1000):
    #     plt.plot(S[i])
    # plt.show()

    # 选出强赎路径
    # 触发条款筛选
    tiexian = 0
    shnum = 0
    for i in range(I):
        for t in range(M):
            if S[i][t] * 100 / K_0 > 130:
                # 多少路径完成赎回
                shnum = shnum + 1
                # 赎回的直接贴现到0期
                tiexian = tiexian + (S[i][t]*100/ K_0) * exp(-r * dt * t)
                S[i] = 0
                break
                # 如果触发赎回
    # 数据清洗,删除赎回的路径,axis = 0 lie
    if shnum == I:
        C_0 = tiexian * exp(-r * dt) / shnum
        P_cb =C_0
        return P_cb
    idx = np.argwhere(np.all(S[:, ...] == 0, axis=1))
    # axis = 0,hang
    SS = np.delete(S, idx, axis=0)
    # V: (I-shnum)*(M+1)
    V = SS - K_0
    # 最小二乘法回归
    for i in range(M - 1):
        Ytemp = SS[:, M - i]*100/ K_0
        Xtemp = SS[:, M - 1 - i]
        # 筛选参与回归的路径,规则为这一期股价>行权价的可以参与回归
        idx = np.argwhere(np.all(Xtemp) <= K_0)
        VV = np.delete(Ytemp, idx)
        X = np.delete(Xtemp, idx)
        # 解释变量为这一期的股价
        # 被解释变量为下一期价值贴现
        Y = VV * exp(-r * dt)
        reg = np.polyfit(X, Y, 2)
        # val为这一期股价对应的持有期望收益
        val = np.polyval(reg, SS[:, M - 1 - i])
        # 对比I条路径下持有期望收益和转股哪个划算，将期权改期期望价值改写为大值
        for j in range(0, I - shnum):
            if val[j] > (SS[j, M - 1 - i]*100/ K_0):
                V[j, M - 1 - i] = max(val[j], 0)
            else:
                V[j, M - 1 - i] = max(0, SS[j, M - 1 - i]*100/ K_0)
        # 到这里第M-1-i步的期望价值已经全部替换
    for ii in range(0,I-shnum):
        if V[ii,1]<(110*exp(r*dt)):
            V[ii,1]=110*exp(r*dt)
    # 计算期权现值
    P_cb = exp(-r * dt) * (sum(V[:, 1]) + tiexian) / I  # tiexian
    return P_cb
    #print(C_name+'CB price %.2f' % P_cb+" Price: %.2f" %PCb)
